// src/app/auth/auth.service.ts

import { Injectable } from '@angular/core';
import{tokenNotExpired} from 'angular2-jwt';
// import { Router } from '@angular/router';
// import 'rxjs/add/operator/filter';
// import * as auth0 from 'auth0-js';
//avoid name not found warnings
declare var Auth0Lock:any;

@Injectable()
export class AuthService {

//   auth0 = new auth0.WebAuth({
//     clientID: '8x_ZsHGOJQNBeKIva9McNuLqnUN5PjDn',
//     domain: 'raviapiitsdindia.auth0.com',
//     responseType: 'token id_token',
//     audience: 'https://raviapiitsdindia.auth0.com/userinfo',
//     redirectUri: 'http://localhost:4200/callback',      
//     scope: 'openid'
//   });

lock= new Auth0Lock('8x_ZsHGOJQNBeKIva9McNuLqnUN5PjDn','raviapiitsdindia.auth0.com',{});

// constructor() {
//     //add callback for lock 'authenticated event'
//     this.lock.on("authenticated",(authResult:any) => {
//         localStorage.setItem('id_token',authResult.id_token);

//     });
// }

constructor() {
    // Add callback for lock `authenticated` event
    this.lock.on("authenticated", (authResult:any) => {
      this.lock.getProfile(authResult.idToken, function(error:any, profile:any){
          if(error){
              throw new Error(error);
          }
            localStorage.setItem('id_token', authResult.idToken);
            localStorage.setItem('profile', JSON.stringify(profile)); 
      });
    });
  }

public login(){
    // call the show method to display
    this.lock.show();
};
public authenticated(){
    //check if there's an unexpired jwt
    // this searches for an item in localstorage with key =='id_token'
    return tokenNotExpired();
};
public logout(){
    localStorage.removeItem('id_token');
};


//   constructor(public router: Router) {}

//   public login(): void {
//     this.auth0.authorize();
//   }

}
